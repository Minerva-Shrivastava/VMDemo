package com.yash.tcvm_final.builder;

import com.yash.tcvm_final.conf.TeaConfig;
import com.yash.tcvm_final.domain.Order;
import com.yash.tcvm_final.enumeration.DrinkTypeEnum;
import com.yash.tcvm_final.exception.ContainerUnderflowException;

public class TeaDrinkBuilder extends AbstractDrinkBuilder{
	
	public TeaDrinkBuilder() {
		setDrinkConfigurer(TeaConfig.getDrinkConfigurer());
	}

	@Override
	public void process(Order order) throws ContainerUnderflowException{
		if(order.getDrinkTypeEnum()==DrinkTypeEnum.TEA){
			super.process(order);
		}else{
			throw new IllegalArgumentException("Wrong Drink Type, required "+DrinkTypeEnum.TEA+" and found "+order.getDrinkTypeEnum());
		}
	}
	
	public static DrinkBuilder getDrinkBuilder(){
		return new TeaDrinkBuilder();
	}
}
