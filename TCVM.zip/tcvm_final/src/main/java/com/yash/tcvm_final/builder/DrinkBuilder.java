package com.yash.tcvm_final.builder;

import com.yash.tcvm_final.conf.IDrinkConfigurer;
import com.yash.tcvm_final.domain.Container;
import com.yash.tcvm_final.domain.Order;
import com.yash.tcvm_final.exception.ContainerUnderflowException;

public interface DrinkBuilder {
	
	void setDrinkConfigurer(IDrinkConfigurer drinkConfigurer);
	void process(Order order) throws ContainerUnderflowException;
	void updateContainer();
	
	Container getContainer();
	
	// some other builder methods will go here like
	// checkUnderflow(Order order), updateReportTracker(Order order), updateContainer() etc.

}
