package com.yash.tcvm_final.conf;

public interface IDrinkConfigurer {
	void configUse();
	void configWaste();
	void configDrinkType();
	void configDrinkRate();
	

}
