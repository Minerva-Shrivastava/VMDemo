package com.yash.tcvm_final.exception;

public class ContainerOverFlowException extends Exception {
	
	public ContainerOverFlowException(){
		
	}
	
	public ContainerOverFlowException(String errMsg){
		super(errMsg);
	}

}
