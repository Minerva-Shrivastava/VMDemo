package com.yash.tcvm_final.builder;

import com.yash.tcvm_final.conf.AbstractDrinkConfigurer;
import com.yash.tcvm_final.conf.IDrinkConfigurer;
import com.yash.tcvm_final.domain.Container;
import com.yash.tcvm_final.domain.Order;
import com.yash.tcvm_final.enumeration.ContainerEnum;
import com.yash.tcvm_final.exception.ContainerUnderflowException;

public abstract class AbstractDrinkBuilder implements DrinkBuilder{
	Container container;
	IDrinkConfigurer dConfigurer;
	
	// report related field is also required. 
	
	int teaRequired;
    int milkRequired;
    int waterRequired;
    int sugarRequired;
    int coffeeRequired;
    
    public AbstractDrinkBuilder() {
		// get the report first here
    	container = Container.getContainer();
    }

	public void setDrinkConfigurer(IDrinkConfigurer drinkConfigurer) {
		this.dConfigurer = drinkConfigurer;
		
	}

	public void process(Order order) throws ContainerUnderflowException {
		checkUnderFlow(order);
		updateContainer();
		order.setStatus(true);
		//updateReportTracker(order)
		
		
		
		
	}

	private void checkUnderFlow(Order order) throws ContainerUnderflowException{
		AbstractDrinkConfigurer drinkConfigurer =  (AbstractDrinkConfigurer) dConfigurer;
		teaRequired =  order.getQuantity() * (drinkConfigurer.getTeaUse() + drinkConfigurer.getTeaWaste());
		if(container.getTea()<teaRequired){
			throw new ContainerUnderflowException(ContainerEnum.TEA + "Insufficient");
		}
		
		milkRequired = order.getQuantity() * (drinkConfigurer.getMilkUse() + drinkConfigurer.getMilkWaste());
		if(container.getMilk()<milkRequired){
			throw new ContainerUnderflowException(ContainerEnum.MILK+ "Insufficient");
		}
		
		waterRequired =  order.getQuantity() *(drinkConfigurer.getWaterUse() + drinkConfigurer.getWaterWaste());
		if(container.getWater()<waterRequired){
			throw new ContainerUnderflowException(ContainerEnum.WATER+ " Insufficient");
		}
		
		sugarRequired =  order.getQuantity() * (drinkConfigurer.getSugarUse() + drinkConfigurer.getSugarWaste());
		if(container.getSugar()<sugarRequired){
			throw new ContainerUnderflowException(ContainerEnum.SUGAR + "Insufficient");
		}
		
		coffeeRequired =  order.getQuantity() * (drinkConfigurer.getCoffeeUse() + drinkConfigurer.getCoffeeWaste());
		if(container.getCoffee()<coffeeRequired){
			throw new ContainerUnderflowException(ContainerEnum.COFFEE + "Insufficient");
		}		
		
	}

	public Container getContainer() {
		
		return this.container;
	}

	public void updateContainer() {
		container.setCoffee(container.getCoffee()-coffeeRequired);
		container.setMilk(container.getMilk()-milkRequired);
		container.setSugar(container.getSugar()-sugarRequired);
		container.setTea(container.getTea()-teaRequired);
		container.setWater(container.getWater()-waterRequired);
		
	}
    
    
}
