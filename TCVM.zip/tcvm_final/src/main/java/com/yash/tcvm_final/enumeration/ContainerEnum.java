package com.yash.tcvm_final.enumeration;

public enum ContainerEnum {
	MILK,
	WATER,
	TEA,
	COFFEE,
	SUGAR

}
