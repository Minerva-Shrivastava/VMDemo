package com.yash.tcvm_final.exception;

public class ContainerUnderflowException extends Exception {

	public ContainerUnderflowException(){
		
	}
	
	public ContainerUnderflowException(String errMsg){
		super(errMsg);
		
	}
}
