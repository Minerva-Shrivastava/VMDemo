package com.yash.tcvm_final.test;

import com.yash.tcvm_final.builder.DrinkBuilder;
import com.yash.tcvm_final.builder.TeaDrinkBuilder;
import com.yash.tcvm_final.domain.Container;
import com.yash.tcvm_final.domain.Order;
import com.yash.tcvm_final.enumeration.DrinkTypeEnum;
import com.yash.tcvm_final.exception.ContainerUnderflowException;

public class TestTeaOrder {

	public static void main(String[] args) throws ContainerUnderflowException {
		DrinkBuilder drinkBuilder =  TeaDrinkBuilder.getDrinkBuilder();
		System.out.println("Initial Conatainer status : "+Container.getContainer());
		
		drinkBuilder.process(new Order(1, DrinkTypeEnum.TEA)); // test for 1 cup tea
		System.out.println("After one cup tea status : "+Container.getContainer());
		
		System.out.println("-----Report can be shown here------");

	}

}
