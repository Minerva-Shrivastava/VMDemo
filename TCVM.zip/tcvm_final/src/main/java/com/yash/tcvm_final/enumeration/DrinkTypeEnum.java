package com.yash.tcvm_final.enumeration;

public enum DrinkTypeEnum {
	
	COFFEE,
	BLACK_COFFEE,
	TEA,
	BLACK_TEA

}
